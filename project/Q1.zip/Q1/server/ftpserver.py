import socket
import threading
import json
import os
import stat
import time

class FTPServer:
    def __init__(self, control_port=20021, data_port=20020):
        self.isroot = False
        self.control_port = control_port
        self.data_port = data_port
        self.server_data_socket = None
        self.server_control_socket = None

    def start(self):
        self.server_data_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_data_socket.bind(('localhost', self.data_port))
        self.server_data_socket.listen(5)

        self.server_control_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_control_socket.bind(('localhost', self.control_port))
        self.server_control_socket.listen(5)

        while True:
            client_socket, addr = self.server_control_socket.accept()
            client_handler = threading.Thread(target=self.handle_client, args=(client_socket,))
            client_handler.start()

    def handle_client(self, client_socket):
        while True:
            try:
                request = client_socket.recv(1024).decode()
                print(f"Received request: {request}")  
                if not request:
                    break

                request_data = json.loads(request)
                cmd = request_data.get("Cmd")

                if cmd == "AUTH":
                    self.AUTH(client_socket, request_data)
                elif cmd == "QUIT":
                    self.QUIT(client_socket)
                    break
                elif cmd == "LIST":
                    self.LIST(client_socket, request_data)
                elif cmd == "GET":
                    self.GET(client_socket, request_data)
                elif cmd == "PUT":
                    self.PUT(client_socket, request_data)
                elif cmd == "DELE":
                    self.DELETE(client_socket, request_data)
                elif cmd == "MPUT":
                    self.MPUT(client_socket, request_data)
                elif cmd == "LISTOK":
                    response = {"StatusCode": 226, "Description": "Directory send ok"}
                    client_socket.send(json.dumps(response).encode())
                elif cmd == "GETOK":
                    response = {"StatusCode": 226, "Description": "Transfer complete"}
                    client_socket.send(json.dumps(response).encode())
                elif cmd == "PUTOK":
                    response = {"StatusCode": 226, "Description": "Transfer complete"}
                    client_socket.send(json.dumps(response).encode())
                elif cmd == "MPUTOK":
                    response = {"FileName":request_data.get("FileName") , "StatusCode": 226, "Description": "Transfer complete"}
                    client_socket.send(json.dumps(response).encode())
                else:
                    response = {"StatusCode": 400, "Description": "Invalid Command"}
                    client_socket.send(json.dumps(response).encode())

            except json.JSONDecodeError as e:
                print(f"JSON Decode Error: {e}")
                break
            except Exception as e:
                print(f"Error: {e}")
                break

        client_socket.close()

    def AUTH(self, client_socket, request_data):
        user = request_data.get("User")
        password = request_data.get("Password")

        if user == "ahmad" and password == "1234":
            self.isroot = True
            response = {"StatusCode": 230, "Description": "Successfully logged in. Proceed"}
        
        else:
            response = {"StatusCode": 430, "Description": "Failure in granting root accessibility"}

        client_socket.send(json.dumps(response).encode())
    
    def QUIT(self , client_socket):
        response = {"StatusCode": 200, "Description": "Connection closed"}
        client_socket.send(json.dumps(response).encode())

    def LIST(self, client_socket, request_data):
        files = os.listdir('.')
        if files:
            response = {"StatusCode": 150, "Description": "PORT command successful", "DataPort": self.data_port}
        else:
            response = {"StatusCode": 210, "Description": "Empty"}

        client_socket.send(json.dumps(response).encode())
        if response["StatusCode"] == 150:
            data_socket, addr = self.server_data_socket.accept()
            self.list_directory(data_socket)
            data_socket.close()

    def GET(self, client_socket, request_data):
        filename = request_data.get("FileName")
        if os.path.exists(filename):
            response =  {"StatusCode": 150, "Description": "OK to send data", "DataPort": self.data_port}
        else:
            response = {"StatusCode": 550, "Description": "File doesn't exist"}
        client_socket.send(json.dumps(response).encode())
        if response["StatusCode"] == 150:
            data_socket, addr = self.server_data_socket.accept()
            self.send_file(filename, data_socket)
            data_socket.close()

    def PUT(self, client_socket, request_data):
        filename = request_data.get("FileName")
        if self.isroot:
            response = {"StatusCode": 150, "Description": "OK to receive data", "DataPort": self.data_port}
        else:
            response =  {"StatusCode": 434, "Description": "The client doesn’t have the root access. File transfer aborted."}
        client_socket.send(json.dumps(response).encode())
        if response["StatusCode"] == 150:
            data_socket, addr = self.server_data_socket.accept()
            self.receive_file(filename, data_socket)
            data_socket.close()
    
    def DELETE(self, client_socket, request_data):
        filename = request_data.get("FileName")
        if self.isroot :
            if os.path.exists(filename):
                os.remove(filename)
                response =  {"StatusCode": 200, "Description": "Successfully deleted"}
            else:
                response =  {"StatusCode": 550, "Description": "File doesn't exist"}
        else:
            response = {"StatusCode": 434, "Description": " The client doesn't have the root access ."}

        client_socket.send(json.dumps(response).encode())

    def MPUT(self, client_socket, request_data):
        filenames = request_data.get("FileNames", [])
        if self.isroot:
            response = {"StatusCode": 150, "Description": "OK to receive data", "DataPort": self.data_port}
        else:
            response =  {"StatusCode": 434, "Description": "The client doesn’t have the root access. File transfer aborted."}
        client_socket.send(json.dumps(response).encode())
        if response["StatusCode"] == 150:
            for filename in filenames:
                data_socket, addr = self.server_data_socket.accept()
                self.receive_file(filename, data_socket)
                data_socket.close()
    
    def list_directory(self, data_socket):
        files = os.listdir('.')
        output = ("-"*95 + "\n"
                  "|{:>12} |{:>10} |{:>12} |{:>20} |{:>10} |{:>12} |\n".format("Name", "Filetype", "Filesize", "Last Modified", "Permission", "User/Group")
                  + "-"*95 + "\n")

        for file in files:
            file_stats = os.stat(file)
            filetype = "Directory" if stat.S_ISDIR(file_stats.st_mode) else "File"
            filesize = file_stats.st_size
            last_modified = time.strftime("%b %d, %Y %H:%M", time.localtime(file_stats.st_mtime))
            permission = oct(file_stats.st_mode)[-4:]
            user_group = f"{file_stats.st_uid}/{file_stats.st_gid}"

            output += "|{:>12} |{:>10} |{:>12}B |{:>20} |{:>10} |{:>12} |\n".format(file, filetype, filesize, last_modified, permission, user_group)

        output += "-"*95
        data_socket.sendall(output.encode())

    def send_file(self, filename, data_socket):
        with open(filename, 'rb') as file:
            while True:
                data = file.read(1024)
                if not data:
                    break
                data_socket.sendall(data)

    def receive_file(self, filename, data_socket):
        with open(filename, 'wb') as file:
            while True:
                data = data_socket.recv(1024)
                if not data:
                    break
                file.write(data)

if __name__ == "__main__":
    address = input("Destination address - if left empty, default address is localhost: ")
    port = input("Port - if left empty, default port is 20021: ")
    data_port = input("Data port - if left empty, default port is 20020: ")
    ftp_server = FTPServer()
    ftp_server.start()
