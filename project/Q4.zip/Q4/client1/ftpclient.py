import socket
import json
import sys

class FTPClient:
    def __init__(self, address, port, data_port):
        self.address = address
        self.port = port
        self.data_port = data_port
        self.isroot = False

    def send_request(self, command):
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((self.address, self.port))
        client.send(command.encode())
        response = client.recv(4096).decode()
        response_data = json.loads(response)
        print()
        print(response_data)
        client.close()
        return response_data

    def send_data(self, filename, port):
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((self.address, port))
        with open(filename, 'rb') as file:
            while True:
                data = file.read(1024)
                if not data:
                    break
                client.sendall(data)
        client.close()

    def receive_data(self, filename, port):
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((self.address, port))
        with open(filename, 'wb') as file:
            total_received = 0
            while True:
                data = client.recv(1024)
                if not data:
                    break
                file.write(data)
                total_received += len(data)
                print(f"Received {total_received} bytes")
        client.close()


    def run(self):
        while True:
            command = input("ftp> ")
            if command.lower() == "quit":
                self.QUIT()
                break
            elif command.lower().startswith("ath"):
                self.authentication(command)
            elif command.lower().startswith("ls"):
                self.LIST(command)
            elif command.lower().startswith("get"):
                self.GET(command)
            elif command.lower().startswith("put"):
                self.PUT(command)
            elif command.lower().startswith("delete"):
                self.DELETE(command)
            elif command.lower().startswith("mput"):
                self.MPUT(command)
            else:
                print("Invalid command")

    def QUIT(self):
        response = self.send_request(json.dumps({"Cmd": "QUIT"}))
        print(response["Description"])
    
    def authentication(self, command):
        _, user, password = command.split()
        auth_data = {
            "Cmd": "AUTH",
            "User": user,
            "Password": password
        }
        response = self.send_request(json.dumps(auth_data))
        if response["StatusCode"] == 230:
            print("ok")
            print(response["Description"])
            self.isroot = True
        else:
            print(print(response["Description"]))
            self.isroot = False
    
    def LIST(self, path):
        response = self.send_request(json.dumps({"Cmd": "LIST"}))
        print(response["Description"])
        if response["StatusCode"] == 150:
            client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client.connect((self.address, response["DataPort"]))
            while True:
                data = client.recv(1024).decode()
                if not data:
                    break
                sys.stdout.write(data)
                sys.stdout.flush()
            client.close()
        response = self.send_request(json.dumps({"Cmd": "LISTOK"}))
        print(response["Description"])
    
    def GET(self, command):
        _, filename = command.split()
        response = self.send_request(json.dumps({"Cmd": "GET", "FileName": filename}))
        if response["StatusCode"] == 150:
            self.receive_data(filename, response["DataPort"])
            print(response["Description"])
            response = self.send_request(json.dumps({"Cmd": "GETOK"}))
            print(response["Description"])
        else:
            print(response["Description"])

    def PUT(self, command):
        _, filename = command.split()
        response = self.send_request(json.dumps({"Cmd": "PUT", "FileName": filename}))
        if response["StatusCode"] == 150:
            self.send_data(filename, response["DataPort"])
            print(response["Description"])
            response = self.send_request(json.dumps({"Cmd": "PUTOK"}))
            print(response["Description"])

        else:
            print(response["Description"])

    def DELETE(self, command):
        _, filename = command.split()
        response = self.send_request(json.dumps({"Cmd": "DELE", "FileName": filename}))
        print(response["Description"])

    def MPUT(self, command):
        filenames = command.split()[1:]
        filenames = filenames[0].split(",")
        response = self.send_request(json.dumps({"Cmd": "MPUT", "FileNames": filenames}))
        print(response["Description"])
        if response["StatusCode"] == 150:
            for filename in filenames:
                self.send_data(filename, response["DataPort"])
                response2 = self.send_request(json.dumps({"Cmd": "MPUTOK", "FileName": filename}))
                print(response2["Description"])

address = input("Destination address - if left empty, default address is localhost: ")
port = input("Port - if left empty, default port is 20021: ")
data_port = input("Data port - if left empty, default port is 20020: ")

ftpclient = FTPClient(address or 'localhost', int(port or 20021), int(data_port or 20020))
ftpclient.run()
